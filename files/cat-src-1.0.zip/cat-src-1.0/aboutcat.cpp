#include "aboutcat.h"

// including <QtGui> saves us to include every class user, <QString>, <QFileDialog>,...

myAboutCAT::myAboutCAT(QWidget *parent)
{
	ui.setupUi(this); // this sets up GUI
}
