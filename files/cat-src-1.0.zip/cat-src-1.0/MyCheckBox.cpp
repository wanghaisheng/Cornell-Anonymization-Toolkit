#include "MyCheckBox.h"


void myCheckBox::setMyChecked(bool checked)
{
	
	if(checked)
		this->setChecked( false );
}