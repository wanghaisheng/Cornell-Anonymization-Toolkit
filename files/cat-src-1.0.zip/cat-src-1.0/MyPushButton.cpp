#include "MyPushButton.h"


void myPushButton::setMyDisabled(bool checked)
{

	if(checked)
		this->setDisabled(true);
}